/** Task2 only: inert, file-origin, same-clock Derya garden7 visit over one accepted
 * task1 development capture. No shelf, ownership, ordinary entry, fortnight,
 * nursing assignment, source return, clock translation or private Person writes.
 * Public HF World/driver owns decide/begin/tick/finish and joint assent. */
import { type CommunityState, type Person, type SimEvent } from '@adam0white/human-framework';
import { type PersonaEnvelope } from '@adam0white/lab-client';
import { type GardenPerson } from './garden-cast.ts';
export declare const VISIT_GAME = "hearsay-cast/7";
export declare const VISIT_OPTION = "garden7/derya-aligned-visit1";
export declare const VISIT_START = 930;
export declare const VISIT_CLOSE = 990;
export declare const VISIT_RETURN_BEFORE = 1170;
export type VisitResources = Record<string, unknown>;
export interface VisitSourceInput {
    packet: unknown;
    predecessor: unknown;
    prefix: unknown;
    world: unknown;
}
export interface VisitSourceRefs {
    packet: string;
    predecessor: string;
    prefix: string;
    world: string;
    raw: string;
    life: string;
}
export type VisitInput = {
    type: 'invite' | 'water' | 'quiet' | 'close';
};
export interface VisitRecordedInput {
    at: number;
    input: VisitInput;
}
export interface VisitRun {
    game: typeof VISIT_GAME;
    option: typeof VISIT_OPTION;
    seed: 7;
    origin: 'controlled-local-file';
    accepted: false;
    submitted: false;
    coarsePreparation: 'zero-elapsed-retained-life/1';
    resources: VisitResources;
    source: VisitSourceRefs;
    initialPeople: Record<GardenPerson, string>;
    opening: string;
    closing: string | null;
    inputs: VisitRecordedInput[];
    minute: number;
    phase: 'visiting' | 'closing' | 'closed' | 'missed-window';
    actualEnd: number | null;
    closingRequested: number | null;
    invitation: {
        at: number;
        delivered: boolean;
        available: boolean;
    } | null;
    waterOffered: boolean;
    people: Record<GardenPerson, Person>;
    community: CommunityState;
    events: SimEvent[];
}
export declare const visitFail: (message: string) => never;
export declare function visitEqual(a: unknown, b: unknown, message: string): void;
export declare function visitSHA(value: unknown): Promise<string>;
export declare function visitStore(resources: VisitResources, value: unknown): Promise<string>;
/** Independent original-E pins plus exact accepted source12 producer output.
 * The packet pin deliberately restricts this prototype to the actual dirty build;
 * a future trusted controller needs its own contract, not a widened authenticity check. */
export declare function validateVisitSource(input: VisitSourceInput): Promise<{
    prefix: unknown;
    world: unknown;
    packet: PersonaEnvelope;
    predecessor: PersonaEnvelope;
    raw: Person;
    life: import("@adam0white/lab-client").PersonaLife;
}>;
/** Rehydrate the exact source packet from a nonrecursive resource table. raw and life each occur once. */
export declare function visitSourceFromResources(resources: VisitResources, refs: VisitSourceRefs): VisitSourceInput;
export declare function createGardenVisit(source: VisitSourceInput): Promise<VisitRun>;
/** Replay restores pinned initial snapshots. It never consults a constructor or shelf. */
export declare function restoreGardenVisitStart(resources: VisitResources, sourceRefs: VisitSourceRefs, initialRefs: Record<GardenPerson, string>): Promise<VisitRun>;
export declare function visitLocation(id: GardenPerson, at: number): string;
/** Player inputs are Hatice's offers, never commands or Derya's assent. */
export declare function gardenVisitInput(value: VisitRun, input: VisitInput): VisitRun;
export declare function visitClosingReason(run: VisitRun): string | null;
/** One ordinary driver minute at a time. No force-finish and no clock/body/goal writes. */
export declare function advanceGardenVisit(value: VisitRun, until: number): Promise<VisitRun>;
