import { VISIT_GAME, VISIT_OPTION, type VisitResources, type VisitRun } from './garden-visit.ts';
export interface GardenVisitSave {
    game: typeof VISIT_GAME;
    version: 'garden-visit-native/1';
    option: typeof VISIT_OPTION;
    seed: 7;
    origin: 'controlled-local-file';
    accepted: false;
    submitted: false;
    coarsePreparation: VisitRun['coarsePreparation'];
    source: VisitRun['source'];
    resources: VisitResources;
    initialPeople: VisitRun['initialPeople'];
    opening: string;
    closing: string | null;
    inputs: VisitRun['inputs'];
    minute: number;
    closingRequested: number | null;
    actualEnd: number | null;
    phase: VisitRun['phase'];
    replaySHA256: string;
    state?: Pick<VisitRun, 'people' | 'community' | 'events' | 'invitation' | 'waterOffered'>;
}
/** Validate the complete source, resource graph, native state and replay before returning detached data. */
export declare function validateGardenVisitSave(value: unknown): Promise<GardenVisitSave>;
/** Replay and public validation enforce the same complete contract. */
export declare function replayGardenVisit(value: unknown): Promise<VisitRun>;
export declare function exportGardenVisit(value: VisitRun, compact?: boolean): Promise<GardenVisitSave>;
/** Public JSON and size/depth/complexity guards precede any Person restoration. */
export declare function importGardenVisit(text: string): Promise<VisitRun>;
