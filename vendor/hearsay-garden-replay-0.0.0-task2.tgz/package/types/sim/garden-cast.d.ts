/** Public profiles come from the released canonical artifact. Private facts stay author-side. */
import { type Person } from '@adam0white/human-framework';
export declare const GARDEN_EDITION = "hearsay-cast/6";
export declare const GARDEN_CAST: {
    readonly hatice: {
        readonly castId: 'hf.cast.hatice.hearsay';
        readonly revision: '1';
        readonly name: 'Hatice';
        readonly age: 48;
        readonly sex: 'female';
        readonly job: 'Tea-garden keeper';
        readonly family: 'She is widowed. Her grown child lives outside the district.';
        readonly profile: {
            readonly honesty: 0.85;
            readonly extraversion: 0.7;
            readonly conscientiousness: 0.7;
            readonly agreeableness: 0.6;
        };
        readonly cue: 'The account from the wedding reception is still in your drawer.';
        readonly fact: 'You encouraged a couple to spend more on their wedding. You called your contribution a gift while privately expecting them to book the garden. You later complained about their ingratitude.';
        readonly repair: 'You acknowledge that your gift came with an expectation you never stated. You correct your complaint with the people who heard you repeat it.';
        readonly refusal: 'You do not discuss the old wedding account. Calling your contribution generous does not resolve the expectation you never stated.';
    };
    readonly derya: {
        readonly castId: 'hf.cast.derya.stairwell';
        readonly revision: '2';
        readonly name: 'Derya';
        readonly age: 44;
        readonly sex: 'female';
        readonly job: 'Night nurse on a short relief assignment';
        readonly family: 'She is single and has temporary lodging near the garden. Her home is flat 5 of Lale Apartmanı, the Lale apartment building.';
        readonly profile: {
            readonly honesty: 0.7;
            readonly extraversion: 0.35;
            readonly agreeableness: 0.6;
            readonly emotionality: 0.5;
            readonly openness: 0.55;
        };
        readonly cue: 'Derya folds an unfinished letter asking about training before ordering breakfast.';
        readonly fact: 'Derya reported a scheduling error before anyone was harmed. Training invitations then stopped. She kept the correspondence, but does not know whether the events were connected.';
        readonly repair: 'Derya writes a specific request for an explanation. Hatice helps check the wording. Nobody has promised a reply or a training place.';
        readonly refusal: 'Derya puts the correspondence away. Her work and family are private. She has not asked anyone at the garden to investigate.';
    };
    readonly dilan: {
        readonly castId: 'hf.cast.dilan.murmur';
        readonly revision: '2';
        readonly name: 'Dilan';
        readonly age: 33;
        readonly sex: 'female';
        readonly job: 'Parcel delivery visitor';
        readonly family: 'Dilan is Aylin’s younger sister. Their mother lives elsewhere.';
        readonly profile: {
            readonly honesty: 0.68;
            readonly conscientiousness: 0.48;
            readonly emotionality: 0.62;
            readonly extraversion: 0.45;
            readonly agreeableness: 0.6;
        };
        readonly cue: 'Dilan checks an old route slip, then looks toward Ece.';
        readonly fact: 'Ece once missed a delivery, and Dilan did it for her. Dilan then let Murat, the depot supervisor, think that Dilan had caused the delay. She hoped Ece would thank her, but she never said so. Ece thought the matter was closed.';
        readonly repair: 'Dilan asks Ece for a short conversation about the old delivery slip. She explains the thanks she expected instead of asking Hatice to pass on an accusation.';
        readonly refusal: 'Dilan keeps the slip. Hatice does not have permission to tell others about the old delivery.';
    };
    readonly nermin: {
        readonly castId: 'hf.cast.nermin.goodhands';
        readonly revision: '1';
        readonly name: 'Nermin';
        readonly age: 45;
        readonly sex: 'female';
        readonly job: 'Visiting agency operator; formerly an alterations tailor';
        readonly family: 'Her grown foster daughter lives independently.';
        readonly profile: {
            readonly honesty: 0.75;
            readonly agreeableness: 0.65;
            readonly conscientiousness: 0.75;
            readonly extraversion: 0.6;
            readonly emotionality: 0.5;
            readonly openness: 0.65;
        };
        readonly cue: 'Nermin asks for a quiet table to review how she runs her agency.';
        readonly fact: 'Nermin described a worker’s placement as a poor match and made the worker’s complaint about unpaid nights sound less serious. She refunded part of the client’s fee before checking what the worker had lost.';
        readonly repair: 'With Nermin’s consent, you review what happened without using client names. She drafts a correction and a letter asking the worker which unpaid hours she can document. Payment and forgiveness are still unsettled.';
        readonly refusal: 'Nermin stops reviewing the case. Hatice does not have permission to repeat what Nermin shared in confidence about her work.';
    };
    readonly aylin: {
        readonly castId: 'hf.cast.aylin.murmur';
        readonly revision: '1';
        readonly name: 'Aylin';
        readonly age: 36;
        readonly sex: 'female';
        readonly job: 'School kitchen cook';
        readonly family: 'She is Dilan’s older sister. Their mother is not involved in events at the garden.';
        readonly profile: {
            readonly honesty: 0.8;
            readonly conscientiousness: 0.8;
            readonly extraversion: 0.55;
            readonly agreeableness: 0.65;
            readonly emotionality: 0.55;
            readonly openness: 0.55;
        };
        readonly cue: 'Aylin declines an evening cooking request with an unusually cheerful smile.';
        readonly fact: 'Aylin has been learning social dance above a tyre shop. She likes being a beginner where nobody expects her to organise the evening. Her class partner is a neighbour, not a secret romance.';
        readonly repair: 'Aylin keeps the evening free and chooses to go to class. You do not tell her family or expect her to perform for anyone.';
        readonly refusal: 'Aylin says she has an evening of her own. She owes no further explanation.';
    };
    readonly ece: {
        readonly castId: 'hf.cast.ece.murmur';
        readonly revision: '1';
        readonly name: 'Ece';
        readonly age: 24;
        readonly sex: 'female';
        readonly job: 'Courier and part-time logistics student';
        readonly family: 'She lives with an aunt. Her parents live elsewhere.';
        readonly profile: {
            readonly honesty: 0.65;
            readonly conscientiousness: 0.7;
            readonly extraversion: 0.65;
            readonly agreeableness: 0.55;
            readonly emotionality: 0.45;
            readonly openness: 0.75;
        };
        readonly cue: 'Ece asks whether anyone may sit at the garden gate without ordering.';
        readonly fact: 'Ece maps places where workers can sit without buying anything. She notes whether there is shade, whether seats have backrests and when each place closes. This is a personal map. It is not an official survey of access for disabled people.';
        readonly repair: 'You agree that the gate bench is free to use during opening hours. Ece checks the hours with you before adding it to the workers’ map.';
        readonly refusal: 'Ece keeps the map informal. Nobody has permission to use it to advertise the garden.';
    };
    readonly riza: {
        readonly castId: 'hf.cast.riza.voice';
        readonly revision: '1';
        readonly name: 'Rıza';
        readonly age: 63;
        readonly sex: 'male';
        readonly job: 'Retired worker; part-time bread-delivery helper';
        readonly family: 'His grown daughter lives away. He visits Istanbul occasionally.';
        readonly profile: {
            readonly extraversion: 0.7;
            readonly agreeableness: 0.7;
            readonly honesty: 0.65;
            readonly conscientiousness: 0.45;
        };
        readonly cue: 'Rıza asks which lane has the blue tiled doorway.';
        readonly fact: 'Rıza keeps doorway sketches and photographs after his daughter sent a picture she thought he would like. He has not shown the collection because he does not want his quiet interest turned into a performance.';
        readonly repair: 'Rıza marks a short walking route along public streets to suggest to his daughter. You leave private courtyards out and let him decide whether to invite her. The visit has not happened.';
        readonly refusal: 'Rıza keeps the sketches for himself. He does not have to share his private interest with garden customers.';
    };
    readonly osman: {
        readonly castId: 'hf.cast.osman.voice';
        readonly revision: '1';
        readonly name: 'Osman';
        readonly age: 55;
        readonly sex: 'male';
        readonly job: 'Produce supplier, market trader and small landlord';
        readonly family: 'He is divorced. His adult son works elsewhere.';
        readonly profile: {
            readonly conscientiousness: 0.75;
            readonly agreeableness: 0.35;
            readonly honesty: 0.6;
            readonly extraversion: 0.5;
        };
        readonly cue: 'Osman brings the account for his produce crates and stops to look at an older receipt.';
        readonly fact: 'Osman opens his account book himself. A former tenant’s repair contribution was never deducted from the final account. He found the note later but kept the money while waiting for a complaint.';
        readonly repair: 'Osman writes the exact correction and addresses a letter about repayment. The letter only proposes repayment. Halil’s separate rent account stays as it was.';
        readonly refusal: 'Osman closes his account book. A generous offer elsewhere would not correct this separate account.';
    };
};
export type GardenPerson = keyof typeof GARDEN_CAST;
export declare const GARDEN_IDS: GardenPerson[];
export declare function gardenOpening(id: GardenPerson, seed: number, now?: number): Person;
/** Duties are host facts, not kinship inferred from shared accommodation. */
export declare function gardenLocation(id: GardenPerson, minute: number): string;
